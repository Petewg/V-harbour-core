Code used by GetBox control
defined in minigui\source\h_getbox.prg

pete.d: 04/05/2016